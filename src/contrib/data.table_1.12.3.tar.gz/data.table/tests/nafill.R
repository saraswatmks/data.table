require(data.table)
test.data.table(script="nafill.Rraw")
